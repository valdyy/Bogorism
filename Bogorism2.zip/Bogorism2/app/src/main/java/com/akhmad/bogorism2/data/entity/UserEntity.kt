package com.akhmad.bogorism2.data.entity

import com.google.gson.annotations.SerializedName

data class UserEntity(

    @field:SerializedName("name")
    val name: String,

    )