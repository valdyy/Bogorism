package com.akhmad.bogorism.ui.factory

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.akhmad.bogorism.data.reference.UserReference
import com.akhmad.bogorism.di.UserInjection
import com.akhmad.bogorism.ui.login.LoginViewModel
import com.akhmad.bogorism.ui.main.MainViewModel
import com.akhmad.bogorism.ui.register.RegisterViewModel

class UserViewModelFactory(private val userRepository: UserReference):
    ViewModelProvider.NewInstanceFactory(){

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when{

            modelClass.isAssignableFrom(RegisterViewModel::class.java) ->{
                RegisterViewModel(userRepository) as T
            }
            modelClass.isAssignableFrom(LoginViewModel::class.java) -> {
                LoginViewModel(userRepository) as T
            }
            modelClass.isAssignableFrom(MainViewModel::class.java) -> {
                MainViewModel(userRepository) as T
            }

            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }

    companion object{
        @Volatile
        private var instance : UserViewModelFactory? = null
        fun getInstance(context: Context): UserViewModelFactory =
            instance ?: synchronized(this){
                instance ?: UserViewModelFactory(UserInjection.provideReference(context))
            }.also { instance = it }
    }
}